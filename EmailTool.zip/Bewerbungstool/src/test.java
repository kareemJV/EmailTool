import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.File;
import java.io.IOException;
import java.util.Properties;

public class test extends Application {

    private TextField emailField;
    private TextField recipientField;
    private TextArea messageArea;
    private Button sendButton;

    private Session session;
    private String sender;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("E-Mail Senden");

        // Erstelle das GridPane für das Layout
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setVgap(5);
        grid.setHgap(5);

        // Erstelle die Textfelder und die Textarea
        Label emailLabel = new Label("Ihre E-Mail:");
        emailField = new TextField();
        Label recipientLabel = new Label("Empfänger:");
        recipientField = new TextField();
        Label messageLabel = new Label("Nachricht:");
        messageArea = new TextArea();

        grid.add(emailLabel, 0, 0);
        grid.add(emailField, 1, 0);
        grid.add(recipientLabel, 0, 1);
        grid.add(recipientField, 1, 1);
        grid.add(messageLabel, 0, 2);
        grid.add(messageArea, 1, 2);

        // Erstelle den Button zum Senden
        sendButton = new Button("Senden");
        sendButton.setOnAction(e -> sendEmail());

        grid.add(sendButton, 1, 3);

        Scene scene = new Scene(grid);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void sendEmail() {
        String email = emailField.getText();
        final String username = email;
        final String password = "yrseqqekdrqcmelx";
        String recipient = recipientField.getText();
        String messageText = messageArea.getText();

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(email));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient));
            message.setSubject("Bewerbung als Werktstudent");
            message.setText(messageText);

            Multipart multipart = new MimeMultipart();
            addAttachments(multipart);
            message.setContent(multipart);

            Transport.send(message);
            System.out.println("Die E-Mail wurde erfolgreich versendet.");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    public void addAttachments(Multipart multipart) {
        try {
            MimeBodyPart lebenslauf = new MimeBodyPart();
            MimeBodyPart zeugnis = new MimeBodyPart();
            MimeBodyPart zeugnis1 = new MimeBodyPart();
            MimeBodyPart zertifikat = new MimeBodyPart();

            lebenslauf.attachFile(new File("C:\\Users\\Karee\\Desktop\\Lebenslauf.pdf"));
            zeugnis.attachFile(new File("C:\\Users\\Karee\\Desktop\\Tool\\Fachoberschule 11 Klasse 1und 2 Halbjahr.PDF"));
            zeugnis1.attachFile(new File("C:\\Users\\Karee\\Desktop\\Tool\\Fachhochschulreife Abschlusszeugnis.PDF"));
            zertifikat.attachFile(new File("C:\\Users\\Karee\\Desktop\\Tool\\Einjähriges Praktikum Eco Computer.PDF"));

            multipart.addBodyPart(lebenslauf);
            multipart.addBodyPart(zeugnis);
            multipart.addBodyPart(zeugnis1);
            multipart.addBodyPart(zertifikat);
        } catch (MessagingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
